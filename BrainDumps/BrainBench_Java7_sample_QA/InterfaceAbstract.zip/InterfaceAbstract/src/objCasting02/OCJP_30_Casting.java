package objCasting02;

public class OCJP_30_Casting {
	public static void main(String[] args) {
		BankAcc01Ver2 ba = new BankAcc01Ver2();
		BankAcc01Ver1 ba1 = convert02(ba);
		BankAcc01 ba2 = convert01(ba1);
		System.out.println(ba2);
	}
	
	public static BankAcc01 convert01(BankAcc01Ver1 ba){
		return ba;
	}
	public static BankAcc01Ver1 convert02(BankAcc01Ver2 ba){
		return ba;
	}
}

class BankAcc01 {
	public int x=10;

	@Override
	public String toString() {
		return "X=" + x;
	}
}

class BankAcc01Ver1 extends BankAcc01 {
	public int y=20;

	@Override
	public String toString() {
		return "Y=" + y + " " + super.toString();
	}
}

class BankAcc01Ver2 extends BankAcc01Ver1 {
	public int z=30;

	@Override
	public String toString() {
		return "Z=" + z + " " +super.toString();
	}
}

/*
  The expected result is...
  a. It throws ClassCast Exception.
  b. Z=30 Y=20 X=10
  c. X=10
  d. None of these.
*/

// Answer:  B