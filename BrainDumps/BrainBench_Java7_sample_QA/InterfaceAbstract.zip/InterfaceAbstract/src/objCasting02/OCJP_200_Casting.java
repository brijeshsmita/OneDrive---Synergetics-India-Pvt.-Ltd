package objCasting02;

public class OCJP_200_Casting {
	
	
	public static void main(String[] args) {
		// Que 5
		/*BankAccVer2 ba2 = new BankAccVer2();
		System.out.println("X:" + ba2.x + " Y:" + ba2.y + " Z:" + ba2.z);
		
		BankAccVer1 ba1 = new BankAccVer2();
		System.out.println("X:" + ba1.x + " Y:" + ba1.y ); // 'z' not allowed.
		
		BankAcc ba = new BankAccVer2();
		System.out.println("X:" + ba.x ); // The 'y' and 'z' not allowed.
		
		Object obj = new BankAccVer2();
		System.out.println(); // The 'x', 'y' and 'z' not allowed.
		*/
		
		// Que 6
		BankAccVer2 ba2 = new BankAccVer2();
		print(ba2);
		
		BankAccVer1 ba1 = new BankAccVer2();
		print(ba1);
		
		Object obj = new BankAccVer2();
		print(obj);
		
		
	}
	
	public static void print(Object obj){
		BankAccVer2 ba = (BankAccVer2) obj;
		System.out.println("X:" + ba.x + " Y:" + ba.y + " Z:" + ba.z);
	}
}


class BankAcc {
	public int x=10;
}

class BankAccVer1 extends BankAcc {
	public int y=20;
}

class BankAccVer2 extends BankAccVer1 {
	public int z=30;
}