package objCasting02;

public class OCJP_20_Casting {
	public static void main(String[] args) {
		OCJP_20_Casting process = new OCJP_20_Casting();
		
		process.process03(new SupClass03()); 
		process.process03(new SubClass04()); 
		process.process03(new SubClass05()); 
	}
	
	public void process03(Object sup){
		//------ Line 1 -------
		cls.print();
	}
}

class SupClass03 {
	public void print(){
		System.out.println("In SupClass03");
	}
}

class SubClass04 extends SupClass03 {
	public void print(){
		System.out.println("In SubClass04");
	}
}

class SubClass05 extends SubClass04 {
	public void print(){
		System.out.println("In SubClass05");
	}
}

/*
	Which statement out of following is missing at Line 1?
	a. SubClass04 cls = (SubClass04) sup;
	b. SupClass03 cls = (SupClass03) sup;
	c. SubClass05 cls = (SubClass05) sup;
	d. None of these.
*/

// Answer: B