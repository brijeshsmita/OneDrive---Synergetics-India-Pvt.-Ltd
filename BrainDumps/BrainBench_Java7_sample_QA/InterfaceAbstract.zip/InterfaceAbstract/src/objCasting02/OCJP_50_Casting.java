package objCasting02;

public class OCJP_50_Casting {
	public static void main(String[] args) {
		BankAcc50Ver01 ba1 = new BankAcc50Ver03();
		
		BankAcc50Ver02 ba2 = convert01(ba1);
		BankAcc50Ver03 ba3 = convert02(ba2);
		
		System.out.println(ba3);
	}
	
	public static BankAcc50Ver02 convert01(BankAcc50Ver01 ba){
		return ba;
	}
	public static BankAcc50Ver03 convert02(BankAcc50Ver02 ba){
		return ba;
	}
}

class BankAcc50Ver01 {
	public int x=10;

	@Override
	public String toString() {
		return "X=" + x;
	}
}

class BankAcc50Ver02 extends BankAcc50Ver01 {
	public int y=20;

	@Override
	public String toString() {
		return "Y=" + y + " " + super.toString();
	}
}

class BankAcc50Ver03 extends BankAcc50Ver02 {
	public int z=30;

	@Override
	public String toString() {
		return "Z=" + z + " " +super.toString();
	}
}

/*
The expected result is...
a. It throws ClassCast Exception.
b. Compiler error on return statement of conversion methods
c. Z=30 Y=20 X=10
d. X=10
*/

// Answer: B