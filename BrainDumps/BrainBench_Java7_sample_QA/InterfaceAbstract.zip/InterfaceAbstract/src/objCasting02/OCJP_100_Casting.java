package objCasting02;

public class OCJP_100_Casting {
	public static void main(String[] args) {
		OCJP_100_Casting process = new OCJP_100_Casting();
		/*
		process.process01(new SupClass()); // Allowed.
		process.process01(new SubClass01()); // Allowed.
		process.process01(new SubClass02()); // Allowed.
		
		//process.process02(new SupClass()); Not allowed.
		process.process02(new SubClass01()); // Allowed.
		// process.process02(new SubClass02()); Not allowed.
		
		// Que 1
		SupClass cls = new SupClass();
		process.process02(cls); //Not allowed. Compiler error. 
		//process.process02((SubClass01)cls);  // Not allowed. ClassCast Exception
		process.process02((SubClass02)cls); //Not allowed. Compiler error.
		
		// Que 2 Done
		process.process03(new SupClass()); // Allowed.
		process.process03(new SubClass01()); // Allowed.
		process.process03(new SubClass02()); // Allowed.
		*/
		
		// Que 4 (Done)
		Object[] obj = new Object[4];
		obj[0] = new Object();
		obj[1] = new SupClass();
		obj[2] = new SubClass01();
		obj[3] = new SubClass02();
		
		for(Object object : obj){
			process.process04(object);
		}
	}
	
	public void process01(SupClass sup){
		sup.print();
	}
	
	public void process02(SubClass01 sup){
		sup.print();
	}
	
	/*public void process03(Object sup){
		sup.print();  // Not allowed
	}*/
	
	public void process04(Object sup){
		//sup.print();  // Not allowed
		System.out.println(sup);
	}
	
	public void process03(Object sup){
		SupClass cls = (SupClass) sup;  // Fill the gap Que 3.
		cls.print();  // Not allowed
	}
	
}

/*class SupClass {
	public void print(){
		System.out.println("In SupClass()");
	}

	@Override
	public String toString() {
		return "In SupClass()";
	}
}

class SubClass01 extends SupClass {
	public void print(){
		System.out.println("In SubClass01");
	}
	
	@Override
	public String toString() {
		return "In SubClass01";
	}
}

class SubClass02 extends SupClass {
	public void print(){
		System.out.println("In SubClass02");
	}
	
	@Override
	public String toString() {
		return "In SubClass02";
	}
}*/