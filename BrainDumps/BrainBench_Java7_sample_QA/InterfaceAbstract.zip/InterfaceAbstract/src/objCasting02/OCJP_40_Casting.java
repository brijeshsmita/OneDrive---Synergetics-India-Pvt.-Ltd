package objCasting02;

public class OCJP_40_Casting {
	public static void main(String[] args) {
		BankAcc40Ver01 ba1 = new BankAcc40Ver03();
		
		BankAcc40Ver02 ba2 = convert01(ba1);
		BankAcc40Ver03 ba3 = convert02(ba2);
		
		System.out.println(ba3);
	}
	
	public static BankAcc40Ver02 convert01(BankAcc40Ver01 ba){
		return (BankAcc40Ver02)ba;
	}
	public static BankAcc40Ver03 convert02(BankAcc40Ver02 ba){
		return (BankAcc40Ver03)ba;
	}
}

class BankAcc40Ver01 {
	public int x=10;

	@Override
	public String toString() {
		return "X=" + x;
	}
}

class BankAcc40Ver02 extends BankAcc40Ver01 {
	public int y=20;

	@Override
	public String toString() {
		return "Y=" + y + " " + super.toString();
	}
}

class BankAcc40Ver03 extends BankAcc40Ver02 {
	public int z=30;

	@Override
	public String toString() {
		return "Z=" + z + " " +super.toString();
	}
}

/*
The expected result is...
a. It throws ClassCast Exception.
b. Z=30 Y=20 X=10
c. X=10
d. None of these.
*/

// Answer : B