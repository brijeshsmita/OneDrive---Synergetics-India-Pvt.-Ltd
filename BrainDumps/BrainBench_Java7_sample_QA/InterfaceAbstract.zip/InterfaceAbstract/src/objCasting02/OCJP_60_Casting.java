package objCasting02;

public class OCJP_60_Casting {
	public static void main(String[] args) {
		BankAcc60Ver01 ba1 = new BankAcc60Ver01();
		
		BankAcc60Ver02 ba2 = convert01(ba1);
		
		System.out.println(ba2);
	}
	
	public static BankAcc60Ver02 convert01(BankAcc60Ver01 ba){
		return (BankAcc60Ver02)ba;
	}
}

class BankAcc60Ver01 {
	public int x=10;

	@Override
	public String toString() {
		return "X=" + x;
	}
}

class BankAcc60Ver02 extends BankAcc60Ver01 {
	public int y=20;

	@Override
	public String toString() {
		return "Y=" + y + " " + super.toString();
	}
}

/*
The expected result is...
a. It throws ClassCast Exception
b. Compiler error on return statement of conversion methods
c. Z=30 Y=20 X=10
d. X=10
*/

// Answer:  A.