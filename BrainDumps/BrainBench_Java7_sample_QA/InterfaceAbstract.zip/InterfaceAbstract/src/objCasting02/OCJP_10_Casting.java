package objCasting02;

public class OCJP_10_Casting {

	public static void main(String[] args) {
		OCJP_10_Casting process = new OCJP_10_Casting();
		
		Object[] obj = new Object[4];
		obj[0] = new Object();
		obj[1] = new SupClass();
		obj[2] = new SubClass01();
		obj[3] = new SubClass02();
		
		for(Object object : obj){
			process.process(object);
		}
	}
	
	public void process(Object sup){
		System.out.println(sup);
	}
}

class SupClass {
	@Override
	public String toString() {
		return "In SupClass()";
	}
}

class SubClass01 extends SupClass {
	@Override
	public String toString() {
		return "In SubClass01";
	}
}

class SubClass02 extends SupClass {
	@Override
	public String toString() {
		return "In SubClass02";
	}
}

/*
 What is expected result.
 	a. Compiler error
 	b. It throws ClassCastException
	c. 	java.lang.Object@15db9742
		In SupClass()
		In SubClass01
		In SubClass02
	d. 	In SubClass02
		In SubClass02
		In SubClass02
		In SubClass02

*/

// Answer: C