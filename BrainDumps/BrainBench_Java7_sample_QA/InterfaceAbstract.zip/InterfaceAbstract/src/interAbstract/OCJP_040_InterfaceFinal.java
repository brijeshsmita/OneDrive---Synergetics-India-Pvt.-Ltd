package interAbstract;

public class OCJP_040_InterfaceFinal implements DeclareStuff1{
	private int y = 2;
	
	@Override
	public void doSomeStuff(int x) {
		x += EASY * y + ++x;			// Line 1
		System.out.println("X: " + x);
	}

	
	public static void main(String[] args) {
		int x = 5;		// Line 2
		new OCJP_040_InterfaceFinal().doSomeStuff(x);
	}
}

interface DeclareStuff1 {
	int EASY = 3;

	void doSomeStuff(int x);
}

/*
a. File will be compiled with errors: Private variables 'y' not accessible in main()
b. Output: X: 14
c. Output: X: 16
d. Output: X: 17 (*)

Justification:
	Line 1 : Right side is calculated first and then operated on left side.
			Though 'x' is incremented at right side, the left side 'x' takes original value.
*/