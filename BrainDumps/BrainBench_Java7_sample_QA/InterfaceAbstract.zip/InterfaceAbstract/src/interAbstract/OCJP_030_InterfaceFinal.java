package interAbstract;

/* Modified from : https://www.javatpoint.com/directload.jsp?val=65
 * Interfaces, Local and Global variables, Parameter passing
 */
public class OCJP_030_InterfaceFinal implements  DeclareStuff{
	private int y = 2;
	
	@Override
	public void doSomeStuff(int x) {
		x += ++EASY * y + ++x;			// Line 1
		System.out.println("X: " + x);
	}

	public static void main(String[] args) {
		int x = 5;		// Line 2
		new OCJP_030_InterfaceFinal().doSomeStuff(x);
	}
}


interface DeclareStuff {
	int EASY = 3;

	void doSomeStuff(int x);
}

/*
a. File will be compiled with errors: Line 1 (*)
b. Output: X: 14
c. Output: X: 16
d. Output: X: 17 

Justification:
	Line 1 : The 'EASY' is a final and thus can not be altered in line 1.
*/