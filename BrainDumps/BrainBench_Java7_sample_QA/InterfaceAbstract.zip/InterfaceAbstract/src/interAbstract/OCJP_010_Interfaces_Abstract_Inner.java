package interAbstract;

/* Choosen from: https://www.javatpoint.com/directload.jsp?val=65
 * Interface, Abstract class, Overriding and Anonymous class
 */

// ----------------------------------------------------------
public class OCJP_010_Interfaces_Abstract_Inner {

	public static void main(String[] args) {
		DoAbstract doAbstract = new DoAbstract(){

			@Override
			public float getAverage(int a, int b, int c) {
				return 0;
			}
		};
		
		doAbstract.getRange(5, 10);
	}
}

interface DoStuff2 {
	float getRange(int low, int high);  // Line 1
}

interface DoMore {
	float getAverage(int a, int b, int c);	
}

abstract class DoAbstract implements DoStuff2, DoMore {
	public float getRange(int low, int high) { return 4.0f ;} // Line 2
}

interface DoAll extends DoMore {
	float getAverage(int a, int b, int c);
}

//-------------------------------------------
/*
   	a. File will be compiled without errors (*)
	b. Compilation error at Line 1
	c. Compilation error at Line 2
	d. No compilation error but ClassCast Exception when executed.
	
	Justification:
		Any class (Here it is DoAbstract) can implement more than one interfaces.
		The Abstract class (Here it is DoAbstract) may not provide all concrete implementations. 
		 	(Not providing implementation of  doAverage() of interface DoMore.
		Therefore: the concrete class (Anonymous class) must provide implementation of doAverage();
*/