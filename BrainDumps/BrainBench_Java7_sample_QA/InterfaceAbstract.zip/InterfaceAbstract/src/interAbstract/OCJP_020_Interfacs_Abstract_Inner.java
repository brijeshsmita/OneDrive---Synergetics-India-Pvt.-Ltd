package interAbstract;

/* Choosen from: https://www.javatpoint.com/directload.jsp?val=65
 * Interface, Abstract class, Overriding and Annonomous class
 */
public class OCJP_020_Interfacs_Abstract_Inner {

	public static void main(String[] args) {
		DoAbstract doAbstract = new DoAbstract(){

			@Override
			public float getAverage(int a, int b, int c) {
				return 0;
			}
		};
		
		doAbstract.getAverage(5, 10, 25);
	}
}

interface DoStuff3 {
	double getAverage(int a, int b, int c);	// Line 1
}

interface DoMore1 {
	float getAverage(int a, int b, int c);
}

abstract class DoAbstract1 implements DoStuff3, DoMore1 { // Line 2
	
}



/*
   	a. File will be compiled without errors
	b. Compilation error at Line 1
	c. Compilation error at Line 2 (*)
	d. No compilation error but ClassCast Exception when put to run.
	
	Justification:
		Any class (Here it is DoAbstract) can implement more than one interfaces.
			In this example, methods of both interfaces are contradicting each other for overloading.
			Such interfaces which are breaking overloading rules can not be implemented to a class at the same time.
*/