package interAbstract02;

public class OCJP_060_Interfaces_Abstract_Inner {
	public static void main(String[] args) {
		DoAbstract01 doAbstract = new DoAbstract01(){  // Line1

			@Override
			public float getAverage(int a, int b, int c) {
				return 0;
			}
		};
		
		doAbstract.getRange(5, 10);
	}
}

abstract class DoStuff4 {
	abstract float getAverage(int a, int b, int c);
}

interface DoStuff5 {
	float getAverage(int a, int b, String c);	
}

abstract class DoAbstract01 extends DoStuff4 implements DoStuff5 {
	public float getRange(int low, int high) { return 4.0f ;} // Line 2
}

/*
a. File will be compiled without errors 
b. Compilation error at Line 1
c. Compilation error at Line 2
d. No compilation error but ClassCast Exception when executed.
*/


/* Answer: B
	Justification:
	Any class (Here it is DoAbstract01) can extend another class and implement more than one interfaces.
	The Abstract class (Here it is DoAbstract01) may not provide all concrete implementations. 
	 	(Not providing implementation of  getAverage() of both interfaces.
	Therefore: the concrete class (Anonymous class) must provide overloaded implementation of doAverage().
*/