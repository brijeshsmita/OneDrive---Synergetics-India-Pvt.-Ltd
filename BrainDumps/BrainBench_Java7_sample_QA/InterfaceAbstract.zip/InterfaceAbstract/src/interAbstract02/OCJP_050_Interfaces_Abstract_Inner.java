package interAbstract02;

public class OCJP_050_Interfaces_Abstract_Inner {

	public static void main(String[] args) {
		DoAbstract doAbstract = new DoAbstract(){  // Line1

			@Override
			public float getAverage(int a, int b, int c) {
				return 0;
			}
		};
		
		doAbstract.getRange(5, 10);
	}
}

interface DoStuff2 {
	float getAverage(int a, int b, int c);
}

interface DoStuff3 {
	float getAverage(int a, int b, String c);	
}

abstract class DoAbstract implements DoStuff2, DoStuff3 {
	public float getRange(int low, int high) { return 4.0f ;} // Line 2
}


/*
   	a. File will be compiled without errors 
	b. Compilation error at Line 1
	c. Compilation error at Line 2
	d. No compilation error but ClassCast Exception when executed.
*/


/*  Answer: B
	Justification:
		Any class (Here it is DoAbstract) can implement more than one interfaces.
		The Abstract class (Here it is DoAbstract) may not provide all concrete implementations. 
		 	(Not providing implementation of  getAverage() of both interfaces.
		Therefore: the concrete class (Anonymous class) must provide overloaded implementation of doAverage().
*/