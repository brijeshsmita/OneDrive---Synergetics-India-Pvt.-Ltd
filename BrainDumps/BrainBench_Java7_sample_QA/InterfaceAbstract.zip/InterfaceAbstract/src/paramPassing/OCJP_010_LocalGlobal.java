package paramPassing;

/* Modified from : https://www.javatpoint.com/directload.jsp?val=65
 * Local and Global variables
 */

public class OCJP_010_LocalGlobal {
	private int y = 10;
	
	void doStuff(int x, int y){
		x++;
		y++; 					// Line 1
	}
	
	public static void main(String[] args){
		int x = 6;
		OCJP_010_LocalGlobal ref = new OCJP_010_LocalGlobal();
		ref.doStuff(x, ref.y);	
		System.out.println("X: " + x + " Y: " + ref.y);
	}
}

/*
a. File will be compiled with errors: Private variables not accessible in main()
b. Compilation error at Line 1
c. Output: X: 7 Y: 11
d. Output: Output: X: 6 Y: 10 (*)

Justification:
	It is passing parameters by value.  Change of values in method doStuff() will not be reflected in original variables.
	The local variable 'y' in doStuff() always override the instance variable 'y'.
*/