package paramPassing;

public class OCJP_030_PassingParams {

	public static void main(String[] args) {
		int a = 5;
		Integer b = 10;
		String c = "15";
		
		MyClass1 cls = new MyClass1(a, b, c);
		
		cls.update();
		System.out.println("A: " + a + " B: " + b + " C: " + c); // Line 1
	}
}

class MyClass1 {
	private int x;
	private Integer y;
	private String z;
	
	public MyClass1(int a, Integer b, String c){
		x = a; y = b; z = c;
	}
	
	void update(){
		x++;
		y++;
		z+="*";
	}
}

/*  What is  inference out of following from the output of above code
a. Primitives, Wrappers and Strings are passed by value.
b. Primitives, Wrappers and String are passed by Reference.
c. As Wrappers and Strings are immutable, there is no value change in line 1. (*)
d. As Wrappers and Strings are mutable, there is a value change in line 1.

Justification:
	The output is: A: 5 B: 10 C: 15 which shows that there is no change in value though update() is invoked.
	The Integers and Strings are passed by Reference still there no value change because of immutability of Integer and String.
*/