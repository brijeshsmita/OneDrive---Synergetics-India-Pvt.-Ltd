package paramPassing;

public class OCJP_050_PassingParams {
	public static void main(String[] args) {
		int a = 5;
		Integer b = 10;
		MyClass3 c = new MyClass3(20);
		
		c.update(a, b);
		System.out.println("A: " + a + " B: " + b + " C: " + c.getX()); // Line 1
	}
}

class MyClass3 {
	private int x;
	
	public MyClass3(int a){
		x = a;
	}
	
	void update(int a, Integer b){
		a++;
		b++;
		x++;
	}
	
	int getX(){
		return x;
	}
}

/*  What is expected outcome?
a. Output: A: 5 B: 10 C: 21*
b. Output: A: 5 B: 10 C: 20
c. Output: A: 6 B: 11 C: 21
d. Output: A: 5 B: 11 C: 21

Justification:
	The output is: A: 5 B: 10 C: 21 which shows that there is no change in value for int and Integer though update() is invoked.
	The Integers is passed by Reference still there no value change because of immutability of Integer.
	But for MyClass3, there is a change in the value because it is customer object which is not immutable and always passed by reference.
*/