package paramPassing;

public class OCJP_040_PassingParams {
	public static void main(String[] args) {
		int a = 5;
		Integer b = 10;
		String c = "15";
		
		MyClass2 cls = new MyClass2(a, b, c);
		
		cls.update();
		System.out.println("A: " + a + " B: " + b + " C: " + c); // Line 1
	}
}

class MyClass2 {
	private int x;
	private Integer y;
	private String z;
	
	public MyClass2(int a, Integer b, String c){
		x = a; y = b; z = c;
	}
	
	void update(){
		x++;
		y++;
		z+="*";
	}
}

/*  What is expected outcome?
a. Output: A: 5 B: 10 C: 15
b. Output: A: 6 B: 11 C: 15
c. Output: A: 5 B: 11 C: 15*
d. Output: A: 5 B: 11 C: 15

Justification:
	The output is: A: 5 B: 10 C: 15 which shows that there is no change in value though update() is invoked.
	The Integers and Strings are passed by Reference still there no value change because of immutability of Integer and String.
*/