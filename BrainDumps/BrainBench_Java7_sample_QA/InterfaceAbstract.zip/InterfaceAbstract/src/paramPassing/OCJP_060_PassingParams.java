package paramPassing;

public class OCJP_060_PassingParams {
	private int x1=10;
	private Integer x2=20;
	private String x3="aaa";
	private MyClass4 x4 = new MyClass4(30);
	
	public int getX1(){
		return ++x1;
	}
	
	public Integer getX2(){
		return ++x2;
	}
	
	public String getX3(){
		return x3+"@@";
	}
	
	public void updateX4(){
		++x4.a;
	}
	
	public static void main(String[] args) {
		OCJP_060_PassingParams services = new OCJP_060_PassingParams();
		System.out.println("X1: " + services.getX1() + " X2: " + services.getX2() + " X3: " + services.getX3());
		services.updateX4();
		System.out.println("X4: " + services.x4.getA());
	}
}

class MyClass4 {
	int a;
	
	public MyClass4(int b){
		this.a = b;
	}
	
	public int getA(){
		return a;
	}
}

/*  What is expected outcome?
a. Output: X1: 10 X2: 20 X3: aaa
		   X4: 30
b. Output: X1: 11 X2: 21 X3: aaa@@
		   X4: 31 (*)
c. Output: X1: 10 X2: 20 X3: aaa
		   X4: 31
d. Output: X1: 10 X2: 20 X3: aaa@@
		   X4: 31

Justification:
	The return data updates the local variables.
*/