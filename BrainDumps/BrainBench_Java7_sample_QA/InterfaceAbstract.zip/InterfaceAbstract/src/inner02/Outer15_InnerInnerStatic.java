package inner02;

public class Outer15_InnerInnerStatic {
	private static int x = 10;
	
	public class Inner01 {
		private static final int y = 20;
		
		public class Inner02 {
			private static final int z = 30;	
		}
	}
	
	public static void main(String[] args) {
		System.out.println(Outer15_InnerInnerStatic.x);
		System.out.println(Outer15_InnerInnerStatic.Inner01.y);
		System.out.println(Outer15_InnerInnerStatic.Inner01.Inner02.z);
		
		Outer15_InnerInnerStatic out = new Outer15_InnerInnerStatic();
		Outer15_InnerInnerStatic.Inner01 oi = out.new Inner01();
		Outer15_InnerInnerStatic.Inner01.Inner02 oii = oi.new Inner02();
		System.out.println(oii.z);
	}
}

/*
 What is the appropriate/correct way to refer to the 'z' within main method?
 a. Outer15_InnerInnerStatic.Inner01.Inner02.z (*)
 b. Outer15_InnerInnerStatic out = new Outer15_InnerInnerStatic();
	Outer15_InnerInnerStatic.Inner01 oi = out.new Inner01();
	Outer15_InnerInnerStatic.Inner01.Inner02 oii = oi.new Inner02();
	System.out.println(oii.z);
c. Inner02.z
d. None of these
 */
