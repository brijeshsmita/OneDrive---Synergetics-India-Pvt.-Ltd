package inner02;

public class Outer04_privAcc {
	private int x = 10;
	public class Inner01 {
		private int x = 20;
		public void printInner(){
			System.out.println("X: " + x);
			print();
		}
		
		public void print(){
			System.out.println("Within print() of inner class");
		}
	}
	
	public void print(){
		System.out.println("Within print() of outer class");
	}
	
	public static void main(String[] args) {
		Outer04_privAcc outer = new Outer04_privAcc();
		Outer04_privAcc.Inner01 inner = outer.new Inner01();
		
		inner.printInner();
	}
}

/* What is expected output?
a. 	X: 20 (*)
	Within print() of inner class
b. 	X: 10
	Within print() of outer class
c. 	X: 10
	Within print() of inner class
d. Compiler error. Methods of same name and field can not be declared in outer and inner class.
*/