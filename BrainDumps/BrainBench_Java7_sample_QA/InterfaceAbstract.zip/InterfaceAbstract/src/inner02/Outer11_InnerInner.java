package inner02;

public class Outer11_InnerInner {
	private int x = 10;
	
	public class Inner01 {
		private int x = 20;
		
		public void print(){
			System.out.println("I-X:" + x);
		}
		
		public class Inner02 {
			private int x = 30;
			public void print(){
				System.out.println("II-X:" + x);  // Line 1
			}
		}
	}
	
	public static void main(String[] args) {
		Outer11_InnerInner outer = new Outer11_InnerInner();

		Outer11_InnerInner.Inner01 oi = outer.new Inner01();
		Outer11_InnerInner.Inner01.Inner02 oii = oi.new Inner02();
		
		oii.print();
	}
}

/*
What is the precedence of 'x'?
	a. first 'x' of Inner02, second 'x' of Inner01, last 'x' of Outer11. (*)
	b. first 'x' of outer11, second 'x' of Inner01, last 'x' of Inner02.
	c. Compiler error.  Ambiguity in Line 1.
	d. Compiler error.  The 'x' can not be directly referred. Can be referred through object reference.
*/