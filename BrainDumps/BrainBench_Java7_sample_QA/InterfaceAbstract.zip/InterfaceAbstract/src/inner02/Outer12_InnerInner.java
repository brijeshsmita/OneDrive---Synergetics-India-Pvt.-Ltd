package inner02;

import inner02.Outer12_InnerInner.Inner01.Inner02;

class Outer12_InnerInner {
	public class Inner01 {
		
		public class Inner02 {
			
			public void print(){
				
			}
		}
	}
	
	public static void main(String[] args) {
		Outer12_InnerInner outer = new Outer12_InnerInner();

		//Outer11_InnerInner.Inner01 oi = outer.new Inner01();
		Inner01 oi = outer.new Inner01();
		Inner02 oii = oi.new Inner02();  // Line 1
		
		oii.print();
	}
}

/*
What is the correct import for Line 1?
a. import inner02.Outer12_InnerInner.Inner01.Inner02; (*)
b. import Outer12_InnerInner.Inner01.Inner02;
c. inner import inner02.Outer12_InnerInner.Inner01.Inner02;
d. Inner classes can not be imported;
*/