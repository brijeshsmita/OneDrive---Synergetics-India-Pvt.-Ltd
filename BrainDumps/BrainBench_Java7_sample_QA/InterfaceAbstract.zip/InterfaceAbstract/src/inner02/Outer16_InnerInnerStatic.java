package inner02;

public class Outer16_InnerInnerStatic {
	private int z = 10;	
	public class Inner01 {
		private int z = 20;	
		public class Inner02 {
			private static final int z = 30;	
		}
	}
	
	public static void main(String[] args) {
		System.out.println(Outer16_InnerInnerStatic.Inner01.Inner02.z);
	}
}

/*
What is the result of these statements?
a. Compiler error for not declaring 'z' as final. (*)
b. 30
c. 10
d. None of these
*/