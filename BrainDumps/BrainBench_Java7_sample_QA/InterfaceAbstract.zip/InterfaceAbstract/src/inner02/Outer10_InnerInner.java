package inner02;

public class Outer10_InnerInner {
	private int x = 10;
	public class Inner01 {
		
		public void print(){
			System.out.println("I-X:" + x);
		}
		
		public class Inner02 {
			
			public void print(){
				System.out.println("II-X:" + x);
			}
		}
	}
	
	public static void main(String[] args) {
		Outer10_InnerInner outer = new Outer10_InnerInner();

		Outer10_InnerInner.Inner01 oi = outer.new Inner01();
		//Outer10_InnerInner.Inner01.Inner02 oii = outer.oi.new Inner02();
		//Outer10_InnerInner.Inner01.Inner02 oii = Outer10_InnerInner.Inner01.new Inner02();
		//Outer10_InnerInner.Inner01.Inner02 oii = new Outer10_InnerInner.Inner01.Inner02();
		Outer10_InnerInner.Inner01.Inner02 oii = oi.new Inner02();
	}
}

/*
 What is the correct syntax of creating an object of Inner02 type?
 a. Outer10_InnerInner.Inner01.Inner02 oii = outer.oi.new Inner02();
 b. Outer10_InnerInner.Inner01.Inner02 oii = Outer10_InnerInner.Inner01.new Inner02();
 c. Outer10_InnerInner.Inner01.Inner02 oii = new Outer10_InnerInner.Inner01.Inner02();
 d. Outer10_InnerInner.Inner01.Inner02 oii = oi.new Inner02(); (*)
 */