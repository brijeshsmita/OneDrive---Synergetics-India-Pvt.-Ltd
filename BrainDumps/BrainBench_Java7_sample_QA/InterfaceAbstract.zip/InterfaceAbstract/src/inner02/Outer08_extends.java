package inner02;

public class Outer08_extends {
	
	public abstract class Inner02 {
		public void print(){
			System.out.println("From Inner02.print()");
		}
	}
	
	public void print(){
		System.out.println("From Outer08.print()");
	}
	
	public static void main(String[] args) {
		ExtendOuter outer = new ExtendOuter();
		Outer08_extends.Inner02 inner = outer.new ExtendInner();
		
		outer.print();
		inner.print();
	}
}

class ExtendOuter extends Outer08_extends {
	
	public class ExtendInner extends Inner02 {

		@Override
		public void print() {
			System.out.println("From ExtendInner.print()");
		}
	}
	
	public void print(){
		System.out.println("From ExtendOuter.print()");
	}
}

/* Find the expected output:
a. Wrong way of extending inner class.
b. The Inner class has Inner02 has been declared as 'abstract' thus can not be extended
c. 	From Outer08.print() 
	From Inner02.print()
d. 	From ExtendOuter.print() (*)
	From ExtendInner.print()
 */