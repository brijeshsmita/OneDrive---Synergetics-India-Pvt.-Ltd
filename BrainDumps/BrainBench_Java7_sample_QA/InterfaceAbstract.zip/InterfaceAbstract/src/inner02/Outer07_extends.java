package inner02;

public class Outer07_extends {
	private int x = 10;
	
	public abstract class Inner02 {
		private int y = 20;
		public abstract void print();
	}
}

abstract class ExtendInner extends Outer07_extends.Inner02 { 

}

/*
a. Compiler error as class 'ExtendInner' is not implementing the abstract print().
b. The inner class can not be extended by a stand-alone class 'ExtendInner'(*)
c. The inner class can not be declared as 'abstract'.
d. The extended class can not be declared as 'abstract'.
*/