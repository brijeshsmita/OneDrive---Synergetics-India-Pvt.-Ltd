package inner02;

public class Outer06_specifiers {
	private int x = 10;
	private final class Inner01 {
		private int y = 20;
		public void print(){
			System.out.println("X:" + x);
		}
	}
	
	private abstract class Inner02 {
		private int y = 20;
		public void print(){
			System.out.println("X:" + x);
		}
	}
}

/* Find the most correct statement/s here
 a. The inner class can not be declared as 'final'
 b. The inner class can not be declared as 'abstract'
 c. The inner class can not be declared as 'private'.
 d. All above statements are wrong. (*)
 */
