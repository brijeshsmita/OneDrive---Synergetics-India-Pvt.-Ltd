package inner02;

public class Outer01_basics {
	private int x = 10;
	public class Inner01 {
		private int y = 20;
		public void print(){
			System.out.println("X:" + x);
		}
	}
	
	public void printInner(){
		Inner01 i = new Inner01();
		System.out.println(i.y);
		i.print();
	}
	
	public static void main(String[] args) {
		Outer01_basics outer = new Outer01_basics();
		
		// Line 1: Creating an object of an inner class Inner01.
		
	}
}

/*
Which one is the correct way to create an object of the inner class within main() at Line 1?
a. outer.Inner01 oi = new outer.Inner01();
b. Outer01.Inner01 oii = Outer01.new Inner01();
c. Outer01.Inner01 oiii = outer.new Inner01(); (*)
d. None of these applicable.

Justification:
	Inner class reference is identified by qualifying inner class with outer class name.
	But the inner class instance can only be identified on object of outer class reference.
*/
