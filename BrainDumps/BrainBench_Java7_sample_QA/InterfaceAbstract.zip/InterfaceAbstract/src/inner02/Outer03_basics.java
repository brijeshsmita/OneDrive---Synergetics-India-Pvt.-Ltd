package inner02;

public class Outer03_basics {
	private int x = 10;
	private class Inner01 {
		private int y = 20;
		private void print(){
			System.out.println("X:" + x);	// Line 1
			printInner();					// Line 2
		}
		
	}
	
	public void printInner(){
		
		System.out.println(y);  			// Line 3
		print();							// Line 4
	}
	
}

/* Which lines out of following needs a correction?
a. All lines are correct.
b. The Line 1 and Line 2.
c. The Line 3 and Line 4 (*)
d. The Line 1 and Line 3

Justification:
	The inner class can refer to the private components of outer class directly.
	But the outer class refers to the private components of inner class on inner class object only.
*/