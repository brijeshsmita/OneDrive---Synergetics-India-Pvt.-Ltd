package inner02;

public class Outer09_extends {
	public abstract class Inner02 {
		public void print(){
			System.out.println("From Inner02.print()");
		}
	}
	
	public void print(){
		System.out.println("From Outer08.print()");
	}
	
	public static void main(String[] args) {
		Outer09_extends outer = new Outer09_extends();
		Outer09_extends.Inner02 inner = outer.new ExtendInner01();  // Line 1
		
		outer.print();
		inner.print();
	}
}

class ExtendOuter01 extends Outer09_extends {
	
	public class ExtendInner01 extends Inner02 {

		@Override
		public void print() {
			System.out.println("From ExtendInner.print()");
		}
	}
	
	public void print(){
		System.out.println("From ExtendOuter.print()");
	}
}

/* Which out of below 
a. Compiler error at Line 1: The ExtendInner01 is not visible to the reference of Outer09 type. (*)
b. Compiler error at Line 1: The mismatch in types of both sides.
c. Compiler error at Line 1: Wrong way of applying the 'new' operator.
d. No compiler error but run time error of casting.
 */
