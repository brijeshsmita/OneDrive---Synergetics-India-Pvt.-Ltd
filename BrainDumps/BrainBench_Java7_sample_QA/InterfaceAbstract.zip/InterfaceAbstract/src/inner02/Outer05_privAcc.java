package inner02;

public class Outer05_privAcc {
	private int x = 10;
	private Inner01 inner;
	
	public Outer05_privAcc(){
		inner = new Inner01();
	}
	
	public class Inner01 {
		private int x = 20;
		
		public void print(){
			
			System.out.println("Within print() of inner class");
		}
	}
	
	public void printOuter(){
		System.out.println("printOuter().x:" + inner.x);
		print();
	}
	
	public void print(){
		System.out.println("Within print() of outer class");
	}
	
	public static void main(String[] args) {
		Outer05_privAcc outer = new Outer05_privAcc();
		outer.printOuter();
	}
}

/* What is expected output?
a. 	printOuter().x:20 (*)
	Within print() of outer class
b. 	printOuter().x:20
	Within print() of inner class
c. 	printOuter().x:10
	Within print() of outer class
d. Compiler error. Need to write a constructor in Inner class as compiler does not write a default constructor.
*/
