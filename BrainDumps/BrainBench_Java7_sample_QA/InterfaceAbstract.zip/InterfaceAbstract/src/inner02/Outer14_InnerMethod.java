package inner02;

public class Outer14_InnerMethod {
	public class Inner01 {
		private int y = 20;
		public Inner01(){
			System.out.println("Y:" + y);
			
			final class Inner02 {
				
			}
		}
	}
}

/*
What is the correct statement out of following?
a. A class declaration within a constructor is not allowed.
b. A class declaration within a constructor is allowed for only private class.
c. A class declaration within a constructor is allowed for only final or abstract class.
d. A class declaration within a constructor is allowed. (*)
*/