package inner02;

public class Outer13_InnerMethod {
	
	public class Inner01 {
		private int y = 20;
		public void print(){
			System.out.println("Y:" + y);
			
			final class Inner02 {
				
			}
		}
	}
}

/*
	What is the correct statement out of following?
	a. A class declaration within a method is not allowed.
	b. A class declaration within a method is allowed for only private class.
	c. A class declaration within a method is allowed for only final or abstract class. (*)
	d. A class declaration within a method is allowed only if method is abstract.
*/