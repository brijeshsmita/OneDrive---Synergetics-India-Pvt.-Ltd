package inner02;

public class Outer02_basics {
	private int x = 10;
	private class Inner01 {
		private int y = 20;
		private void print(){
			System.out.println("X:" + x);	// Line 1
			printInner();					// Line 2
		}
	}
	
	public void printInner(){
		Inner01 i = new Inner01();
		System.out.println(i.y);  			// Line 3
		i.print();							// Line 4
	}
}

/* Which one is the most suitable sentence on above code out of following?
a. The outer class can not refer to the private methods and fields of inner class.
b. The inner class can not refer to the private methods and fields of outer class.
c. The outer class has to refer to the components of inner class on instance of inner class. (*)
d. The inner class has to refer to the components of outer class only if they are final.
*/