package collections03.al;

import java.util.ArrayList;

public class CollectAL110_api {

	public static void main(String[] args) {
		ArrayList<Integer> al2 = new ArrayList<>();
		ArrayList<Integer> al3 = new ArrayList<>();
		
		al2.add(25); al3.add(10); al2.add(35); 
		al3.add(5); al3.add(30); al2.add(15);
		
		for(Integer i : al2){
			al3.add(0, i);
		}
		al2.add(null);
		for(Integer i : al3){
			al2.add(0, i);
		}
		
		int idx1 = al2.indexOf(25); // 3
		int idx2 = al2.lastIndexOf(25); // 6
		
		System.out.println(al2);
		System.out.println(al2.get(idx2+idx1));
	}
}

/*
The nearest output of this code is....
	a. 25
	b. null (*)
	c. 15
	d. 30
*/