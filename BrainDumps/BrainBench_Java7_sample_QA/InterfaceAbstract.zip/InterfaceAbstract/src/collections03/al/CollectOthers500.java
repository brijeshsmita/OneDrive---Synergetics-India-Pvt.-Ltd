package collections03.al;

import java.util.HashSet;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Spliterator;

/*
 * Observations:
 * 	1. Allows null but not duplicates.
 * 	2. For duplicates, does not throw exception but refuses new duplicate.
 * 	3. Does not support ListIterator.
 * 	4. Does not support set(), indexOf(), lastIndexOf(), ensureCapacity(), trimToSize() etc.
 */
public class CollectOthers500 {

	public static void main(String[] args) {
		//HashSet<Emp> el = new HashSet<Emp>();

		/*
		// Can it accepts 'null' more than once?
		// Answer:  NO-Accepts once.
		el.add(null);
		el.add(null);
		
		System.out.println(el);
		*/
		
		/*
		// If duplicate is added, which item it retains? Old or new.  
		// Answer: Refuses but does not overwrite second one.
		
		// Which method following code uses internally? Equals/hashCode or both
		// Answer: Uses both.  Both must be overridden.
		Emp e1 = new Emp(1, "a");
		Emp e2 = new Emp(1, "b");
		
		el.add(e1);
		el.add(e2);
		
		System.out.println(el);
		*/
		/*
		// What are all traversal ways available?
		for(Emp emp : el){			
			System.out.println(emp);
		}
		
		el.forEach(emp -> System.out.println(emp));
		
		Iterator<Emp> it = el.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
		
		 
		//List Iterator not available
		
		ListIterator<Emp> lit = el.listIterator();
		while(lit.hasNext()){
			System.out.println(lit.next());
		}
		*/
		
	}
}


/*class Emp {
	int empId;
	String eName;
	
	public Emp(int empId, String eName){
		this.empId = empId;
		this.eName = eName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + empId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Emp other = (Emp) obj;
		if (empId != other.empId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", eName=" + eName + "]";
	}
}*/