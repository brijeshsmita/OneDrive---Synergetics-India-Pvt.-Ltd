package collections03.al;

import java.util.HashSet;
import java.util.LinkedHashSet;

public class CollectHS350_nested {

	public static void main(String[] args) {
		HashSet<LinkedHashSet<String>> outerSet = new HashSet<>();
		LinkedHashSet<String> innerSet1 = new LinkedHashSet<>();
		innerSet1.add("aaa"); innerSet1.add("ccc"); innerSet1.add("eee");
		outerSet.add(innerSet1);
		
		LinkedHashSet<String> innerSet2 = new LinkedHashSet<>();
		innerSet2.add("ppp"); innerSet2.add("ttt"); innerSet2.add("rrr");
		outerSet.add(innerSet2);
		
		for(LinkedHashSet<String> set : outerSet){
			for(String str : set){
				System.out.print(str + ", ");
			}
			System.out.println();
		}
		/*
		for(String set : outerSet){
			for(LinkedHashSet<String> str : set){
				System.out.print(str + ", ");
			}
			System.out.println();
		}
		*/
		/*
		for(LinkedHashSet<String> set : outerSet){
			System.out.println(set);
		}
		*/
		/*
		for(String set : outerSet){
			System.out.println(set);
		}
		*/
	}
}

/*
	To traverse the HashSet 'outerSet' for each string, which of the following construct is most suitable?
	a. for(LinkedHashSet<String> set : outerSet){ (*)
			for(String str : set){
				System.out.print(str + ", ");
			}
			System.out.println();
		}
		
	b. for(String set : outerSet){
			for(LinkedHashSet<String> str : set){
				System.out.print(str + ", ");
			}
			System.out.println();
		}
	c. for(LinkedHashSet<String> set : outerSet){
			System.out.println(set);
		}
	d. for(String set : outerSet){
			System.out.println(set);
		}
*/