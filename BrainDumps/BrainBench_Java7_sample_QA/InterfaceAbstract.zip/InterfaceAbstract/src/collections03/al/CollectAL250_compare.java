package collections03.al;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class CollectAL250_compare {

	public static void main(String[] args) {
		ArrayList<Integer> al2 = new ArrayList<>();
		ArrayList<Integer> al3 = new ArrayList<>();
		
		al2.add(25); al3.add(10); al2.add(35); 
		al3.add(5); al3.add(30); al2.add(15);
		al3.addAll(al2);
		al3.addAll(0, al2);
		al3.add(50);
		
		Collections.sort(al3, new Ordering());
		System.out.println(al3);
	}
}

class Ordering implements Comparator<Integer>{

	@Override
	public int compare(Integer arg0, Integer arg1) {
		
		return arg1.compareTo(arg0);
	}
}

/* What is the expected output?
	a. [50, 35, 35, 30, 25, 25, 15, 15, 10, 5](*)
	b. [5, 10, 15, 15, 25, 25, 30, 35, 35, 50]
	c. [25, 35, 15, 10, 5, 30, 25, 35, 15, 50]
	d. None of these
*/