package collections03.al;

import java.util.HashSet;

public class CollectHS400_equals {

	public static void main(String[] args) {
		HashSet<Emp2> el = new HashSet<>();
		
		Emp2 e1 = new Emp2(1, "a");
		Emp2 e2 = new Emp2(2, "b");
		
		el.add(e1);
		el.add(e2);
		
		System.out.println(el);
		Emp2 e3 = new Emp2(3, "c");
		System.out.println(el.contains(e3));  // Line 1
	}
}

class Emp2 {
	int empId;
	String eName;
	
	public Emp2(int empId, String eName){
		this.empId = empId;
		this.eName = eName;
	}

	@Override
	public int hashCode() {
		return empId;
	}

	@Override
	public boolean equals(Object obj) {
		return true;
	}
	
	@Override
	public String toString() {
		return "Emp [empId=" + empId + "]";
	}
}

/*
	What is the expected result?
	a. Exception as equals()/hashCode() are not properly written.
	b. Compile time error on Line 1 as contains() not available in HashSet.
	c. Output:  [Emp [empId=1]]
				true
	d. Output:  [Emp [empId=1], Emp [empId=2]] (*)
				false
*/