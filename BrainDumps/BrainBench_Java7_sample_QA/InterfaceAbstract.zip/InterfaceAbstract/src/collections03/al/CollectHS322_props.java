
/*
 If for HashSet internal capacity is 80 and the load factor is 0.75,
 	For how many elements in it, the number of buckets are increased or
 	HashSet is rehashed?
 	a. 100
 	b. 75
 	c. 60 (*)
 	d. 140
*/ 
