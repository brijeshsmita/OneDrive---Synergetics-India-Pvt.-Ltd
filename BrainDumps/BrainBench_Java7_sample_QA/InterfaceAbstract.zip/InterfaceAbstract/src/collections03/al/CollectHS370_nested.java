package collections03.al;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;

public class CollectHS370_nested {

	public static void main(String[] args) {
		HashSet<LinkedList<String>> outerSet = new HashSet<>();
		LinkedList<String> innerList1 = new LinkedList<>();
		innerList1.add("aaa"); innerList1.add("ccc"); innerList1.add("eee");
		outerSet.add(innerList1);
		
		LinkedList<String> innerList2 = new LinkedList<>();
		innerList2.add("ppp"); innerList2.add("ttt"); innerList2.add("rrr");
		outerSet.add(innerList2);
		
		// Construct 1
		outerSet.forEach(lst -> {
			lst.forEach(val -> System.out.print(val + ", "));
			System.out.println();
		});
	}
}

/*
	What is the most probable result of the code?
	a. Run time error in 'Construct 1'.
	b. Compile time error in 'Construct 1'.
	c. No error but code will not traverse each string as expected.
	d. Successful traversal of each string. (*)
*/