package collections03.al;

import java.util.ArrayList;
import java.util.Collection;

import java.util.LinkedHashSet;

public class CollectHS320_props {

	public static void main(String[] args) {
		ArrayList<Integer> al2 = new ArrayList<>();
		al2.add(25); al2.add(5); al2.add(25); 
		al2.add(35); al2.add(30); al2.add(25);
		
		Collection<Integer> intCollect = null;
		// .... ; //Line 1
		intCollect.addAll(al2);
		
		System.out.println(intCollect);
	}
}

/*
	If output of the above code for every execution is 
		[25, 5, 35, 30]
	What kind of Collection is needed at Line 1?
	a. HashSet
	b. LinkedHashSet (*)
	c. ArrayList
	d. LinkedList
	e. TreeSet
*/