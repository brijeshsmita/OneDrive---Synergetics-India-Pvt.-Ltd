/*
	Which statement out of following is true when a collection is declared as Immutable?
	a. Allows not all but few structural changes like remove().
	b. Design a proxy wrapper around original collection where structural methods
		are declared to throw 'UnsupportedOperationException'. (*)
	c. The structural methods on original collection are declared forbidden.
	d. Makes the byte level instrumentation to prevent structural changes on the collection.
*/
