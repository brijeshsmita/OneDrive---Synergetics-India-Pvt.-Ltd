package collections03.al;

import java.util.ArrayList;
import java.util.ListIterator;

public class CollectAL050_api {

	public static void main(String[] args) {
		ArrayList<Integer> al2 = new ArrayList<>();
		ArrayList<Integer> al3 = new ArrayList<>();
		
		al2.add(25); al3.add(10); al2.add(35); 
		al3.add(5); al2.add(30); al3.add(15);
		
		for(Integer i : al2){
			al3.add(0, i);
		}
		
		ListIterator<Integer> li = al2.listIterator(al2.size());
		while(li.hasPrevious()) {
			al3.set(0, li.previous());
		}
	
		System.out.println(al3);
	}
}

/*
	The nearest output of this code is....
	a. [25, 5, 15]
	b. [25, 10, 25, 5, 30, 15]
	c. [25, 35, 30, 30, 35, 25, 10, 5, 15]
	d. [30, 35, 25, 10, 5, 15]
	e. [25, 35, 25, 10, 5, 15] (*)
	
*/