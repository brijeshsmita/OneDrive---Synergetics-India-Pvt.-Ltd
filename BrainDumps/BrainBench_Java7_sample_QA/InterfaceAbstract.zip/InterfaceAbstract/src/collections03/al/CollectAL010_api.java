package collections03.al;

import java.util.ArrayList;
import java.util.List;

public class CollectAL010_api {

	public static void main(String[] args) {
		ArrayList<Integer> newEntries = new ArrayList<>();
		newEntries.add(2); newEntries.add(4);
		newEntries.add(0, 6);				// Line 1
		
		ArrayList<Integer> entries = new ArrayList<>();
		entries.add(5); entries.add(15); entries.add(10);
		entries.addAll(newEntries);
		entries.addAll(2, newEntries); 
		
		List<Integer> selected = entries.subList(2, 5);
		System.out.println(selected);	
	}
}

/*
  The nearest expected output is...
  a. An exception 'IndexOutOfBound' at Line 1.
  b. [6, 2, 4, 10]
  c. [6, 2, 4] 
  d. [6, 2, 4, 10, 6]
*/
// c