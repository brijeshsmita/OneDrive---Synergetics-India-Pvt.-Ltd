package collections03.al;

import java.util.ArrayList;
import java.util.Iterator;

public class CollectAL220_iterate {

	public static void main(String[] args) {
		ArrayList<Integer> al2 = new ArrayList<>();
		ArrayList<Integer> al3 = new ArrayList<>();
		Iterator<Integer> it = al3.iterator();
		
		al2.add(25); al3.add(10); al2.add(35); 
		al3.add(5); al3.add(30); al2.add(15);
		
		al3.addAll(0, al2);
	
		al3.add(50);
		
		for(Integer i : al3){						// Construct 1
			System.out.print(i+", ");
		}
		System.out.println();
		
		al3.forEach(i->System.out.print(i+", "));  	// Construct 2
		
		System.out.println();
		
		while(it.hasNext()){						// Construct 3
			System.out.print(it.next()+", ");
		}
	}
}

/*
	What is the possible result of these statements?
	a. Construct 1 fails
	b. Construct 2 fails
	c. Construct 3 fails (*)
	d. Each construct shows result as 25, 35, 15, 10, 5, 30, 50,
*/