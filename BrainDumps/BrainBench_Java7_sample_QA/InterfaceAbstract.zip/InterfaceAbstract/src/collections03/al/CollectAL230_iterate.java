package collections03.al;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class CollectAL230_iterate {

	public static void main(String[] args) {
		ArrayList<Integer> al2 = new ArrayList<>();
		ArrayList<Integer> al3 = new ArrayList<>();
		
		al2.add(25); al3.add(10); al2.add(35); 
		al3.add(5); al3.add(30); al2.add(15);
		al3.addAll(0, al2);
		al3.add(50);
		
		for(Integer i : al3){							// Construct 1
			System.out.print(i+", ");
		}
		System.out.println();
		
		al3.forEach(i->System.out.print(i+", "));  		// Construct 2
		
		System.out.println();
		Iterator<Integer> it = al3.iterator();
		
		while(it.hasNext()){							// Construct 3
			System.out.print(it.next()+", ");
		}
		
		System.out.println();
		ListIterator<Integer> lit = al3.listIterator(); // Construct 4
		while(lit.hasNext()){
			System.out.print(lit.next()+", ");
		}
		
	}
}

/*
What is the possible result of these statements?
	a. Construct 1 fails
	b. Construct 2 fails
	c. Construct 3 fails 
	e. Construct 4 fails 
	e. Each construct shows result as 25, 35, 15, 10, 5, 30, 50, (*)
*/