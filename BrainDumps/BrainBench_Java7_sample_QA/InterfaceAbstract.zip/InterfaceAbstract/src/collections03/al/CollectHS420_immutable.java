package collections03.al;

import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

public class CollectHS420_immutable {

	public static void main(String[] args) {
		HashSet<List<String>> oSet = new HashSet<>();
		
		LinkedList<String> iList1 = new LinkedList<>();
		iList1.add("aaa"); iList1.add("ccc"); iList1.add("eee");
		List<String> iListu1 = Collections.unmodifiableList(iList1);  // Line 1
		
		LinkedList<String> iList2 = new LinkedList<>();
		iList2.add("ppp"); iList2.add("ttt"); iList2.add("rrr");
		List<String> iListu2 = Collections.unmodifiableList(iList2);
		
		LinkedList<String> iList3 = new LinkedList<>();
		iList3.add("xxx"); iList3.add("yyy"); iList3.add("zzz");
		List<String> iListu3 = Collections.unmodifiableList(iList3);
		
		oSet.add(iListu1);
		oSet.add(iListu2);
		
		iList1.add("bbb");	// Stmt 1
		iListu2.add("ccc");	// Stmt 2
		oSet.add(iListu3);	// Stmt 3
	}
}

/*
	What is the result of execution?
	a. ClassCastException at Line 1
	b. UnsupportedOperationException at Stmt 1
	c. UnsupportedOperationException at Stmt 2 (*)
	d. UnsupportedOperationException at Stmt 3
	e. Code executed successfully
*/