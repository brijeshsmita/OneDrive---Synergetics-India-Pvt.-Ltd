package collections03.al;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class CollectHS410_immutable {
	public static void main(String[] args) {
		HashSet<Emp3> el = new HashSet<>();
		
		Emp3 e1 = new Emp3(1, "a");
		Emp3 e2 = new Emp3(2, "b");
		el.add(e1);
		el.add(e2);
		
		Set<Emp3> elImm = Collections.unmodifiableSet(el);
		Iterator<Emp3> it = elImm.iterator();
		Emp3 e3 = it.next();
		e3.setName("ppp");  // Stmt 1
		elImm.add(new Emp3(4, "qqq")); // Stmt 2
		e3.setEmpId(4);  // Stmt 3
	}
}

class Emp3 {
	int empId;
	String eName;
	
	public Emp3(int empId, String eName){
		this.empId = empId;
		this.eName = eName;
	}

	@Override
	public int hashCode() {
		return empId;
	}

	@Override
	public boolean equals(Object obj) {
		return true;
	}
	
	public void setName(String eName){
		this.eName = eName;
	}
	
	public void setEmpId(int empId){
		this.empId = empId;
	}
	
	@Override
	public String toString() {
		return "Emp [empId=" + empId + "]";
	}
}

/*
	What is the result of this program?
	a. Executed successfully.
	b. UnsupportedOperationException at Statement Stmt 1.
	c. UnsupportedOperationException at Statement Stmt 2. (*)
	d. UnsupportedOperationException at Statement Stmt 3.
	e. Exception from elsewhere.
*/