package collections03.al;

import java.util.ArrayList;

public class CollectAL200_api {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<>(100); // Line 1
		al.add(5); al.add(10); al.add(15);
		
		al.ensureCapacity(200);  // Line 2
		al.trimToSize();		 // Line 3
		al.ensureCapacity(50); 	 // Line 4
	}
}

/* Which lines out of these, relinquishes un-used memory?
	a. Line 3 and 4 (*)
	b. Only Line 2
	c. Line 2 and 4
	d. Line 1
*/