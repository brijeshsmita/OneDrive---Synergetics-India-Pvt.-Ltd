package collections03.al;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

public class CollectHS310_props {

	public static void main(String[] args) {
		ArrayList<Integer> al2 = new ArrayList<>();
		al2.add(25); al2.add(10); al2.add(35); 
		al2.add(5); al2.add(30); al2.add(25);
		
		HashSet<Integer> intSet = new HashSet<>();
		intSet.addAll(al2);
		Collections.shuffle(al2);
		intSet.addAll(al2);
		System.out.println(al2);
		System.out.println(intSet);
	}
}

/*
	What is expected result of this code?
	a. Throws Exception as 'null' is not allowed in HashSet
	b. Throws Exception as duplicate employee not allowed
	c. The addAll() is not available on HashSet.
	c. [35, 5, 25, 10, 30] (*)
	d. [25, 35, 5, 10, 30, 25, 25, 35, 5, 10, 30, 25]
*/