/*

Following are few pairs of methods

Pair 1: set(), indexOf()
Pair 2: ensureCapacity(), trimToSize()
Pair 3: iterator(), listIterator()
Pair 4: clear(), isEmpty()
Pair 5: addAll(), removeAll()

Which pair/s is fully supported by HashSet.
	a. Pair 4 and 5 (*)
	b. Pair 3 and 5
	c. Pair 1 and 3
	d. Pair 2 and 3
	e. None of the mentioned pairs
*/