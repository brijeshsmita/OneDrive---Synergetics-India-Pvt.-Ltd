package collections03.al;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ListIterator;

public class CollectHS330_api {

	public static void main(String[] args) {
		ArrayList<Integer> al2 = new ArrayList<>();
		al2.add(25); al2.add(10); al2.add(35); 
		al2.add(5); al2.add(30); al2.add(25);
		
		HashSet<Integer> intSet = new HashSet<>();
		intSet.addAll(al2);

		// Construct 1
		for(Integer num : intSet){			
			System.out.println(num);
		}
		
		// Construct 2
		intSet.forEach(num -> System.out.print(num + ", "));
		
		// Construct 3
		Iterator<Integer> iterate = intSet.iterator();
		while(iterate.hasNext()){
			System.out.println(iterate.next());
		}
		
		// Construct 4
		ListIterator<Emp> lIterate = iterate.listIterator();
		while(lIterate.hasNext()){
			System.out.println(lIterate.next());
		}
	}
}

/*
	Which construct is Odd man out here?
	a. Construct 1
	b. Construct 2
	c. Construct 3
	d. Construct 4 (*)
	e. All constructs traverse HashSet irrespective of order
*/