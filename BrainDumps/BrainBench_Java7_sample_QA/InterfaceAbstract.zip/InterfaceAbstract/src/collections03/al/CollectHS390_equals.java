package collections03.al;

import java.util.HashSet;

public class CollectHS390_equals {

	public static void main(String[] args) {
		HashSet<Emp1> el = new HashSet<Emp1>();
		
		Emp1 e1 = new Emp1(1, "a");
		Emp1 e2 = new Emp1(1, "b");
		
		el.add(e1);
		el.add(e2);
		
		System.out.println(el);
	}
}

class Emp1 {
	int empId;
	String eName;
	
	public Emp1(int empId, String eName){
		this.empId = empId;
		this.eName = eName;
	}

	@Override
	public int hashCode() {
		// ............
	}

	@Override
	public boolean equals(Object obj) {
		Emp1 other = (Emp1) obj;
		if (empId != other.empId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Emp [empId=" + empId + "]";
	}
}

/*
	What kind of hashCode() should be written to avoid duplicates in the HashSet?
	a. public int hashCode() {
		return super.hashCode;
	}
	
	b. public int hashCode() { (*)
		return empId;
	}
	
	c. public int hashCode() { 
		return 0;
	}
	
	d. @Override
	public int hashCode() {
		return new String(empId);
	}
	
	e. None of these
*/