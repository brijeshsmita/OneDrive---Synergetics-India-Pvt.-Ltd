package collections03.al;

import java.util.ArrayList;
import java.util.List;

/*
 * The add(value) appends and increases range of the index.
 * The add(idx, value) inserts a value at the valid index.  For invalid index, throws exception.
 * Accepts null even in duplicates.
 * The set() overwrites at the valid index.  Can not increase the range of the index.
 * Increase in capacity does not change its size.
 */
public class CollectAl500 {

	public static void main(String[] args) {
		//int[] arr = { 25, 10, 35, 20, 5, 30, 15 };
		ArrayList<Integer> al = new ArrayList<>();
		
		al.add(25); al.add(10); al.add(35); al.add(20); al.add(5); al.add(30); al.add(15);
		
		//System.out.println(al.get(7));  // Index out of bound.
		
		al.add(7,  40);
		System.out.println(al.get(7));
		
		//al.add(9, 45); // Index out of bound.
		
		//al.set(9,  45); // Index out of bound.
		
		// Setting null
		al.add(8, null);
		al.add(9, null);
		
		System.out.println(al);
		
		// Increase in capacity does not change its size.
		al.ensureCapacity(15);
		System.out.println(al.size());
		
		// Removal.
		System.out.println(al+" "+al.size());
		al.remove(8);
		System.out.println(al+" "+al.size());
		
		// All types of queries
		ArrayList<Integer> al1 = new ArrayList<>();
		al1.add(2); al1.add(4);
		
		al.addAll(al1);
		System.out.println(al);
		
		al.addAll(2, al1);
		System.out.println(al);
		
		al.addAll(13, al1);
		System.out.println(al);
		/*
		List<Integer> al2 = al.subList(4, 7);
		System.out.println(al2);
		
		System.out.println(al.size());
		al.trimToSize();
		System.out.println(al.size());
		
		System.out.println(al.indexOf(25));
		System.out.println(al.lastIndexOf(null));
		System.out.println(al.removeIf(val->val==null));
		System.out.println(al);
		System.out.println(al.removeIf(val->val>=30));
		System.out.println(al);
		
		al.removeAll(al1);
		System.out.println(al);
		*/
	}
	
}
