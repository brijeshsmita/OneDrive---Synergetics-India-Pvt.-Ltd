package collections03.al;

import java.util.HashSet;
import java.lang.String;

public class CollectHS380_extends {

	public static void main(String[] args) {
		MyHashSet<String> mySet = new MyHashSet<String>();
		mySet.add("aaa");  // Line 1
		mySet.add("cccc");
		
		System.out.println(mySet);
	}
}

@SuppressWarnings("hiding")
class MyHashSet<String> extends HashSet<String> {
	@Override
	public boolean add(String e) {
		return super.add(e);
	}
}

/*
	What is the expected result of the code?
	a. Code execute successfully with output [aaa, cccc]
	b. Compile time error as HashSet is final and thus not extendible.
	b. Compile time error as add() in HashSet is final and thus not overridable.
	c. Runtime exception 'ClassCastException' at Line 1.
*/