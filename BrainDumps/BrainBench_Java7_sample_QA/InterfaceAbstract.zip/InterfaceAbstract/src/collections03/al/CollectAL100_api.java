package collections03.al;

import java.util.ArrayList;
import java.util.HashSet;

public class CollectAL100_api {

	public static void main(String[] args) {
		ArrayList<Integer> al2 = new ArrayList<>();
		ArrayList<Integer> al3 = new ArrayList<>();
		
		al2.add(25); al3.add(10); al2.add(35); 
		al3.add(5); al3.add(30); al3.add(15);
		
		for(Integer i : al2){
			al3.add(0, i);
		}
		
		for(Integer i : al3){
			al2.add(0, i);
		}
		HashSet<Integer> hs = new HashSet<>();
		for(Integer i : al2){
			hs.add(i);
		}
		hs.removeIf(val -> val%10 == 0);
		System.out.println(hs);
	}
}

/*
The nearest output of this code is....
	a. [35, 10, 25, 5, 30, 15]
	b. [15, 5, 25, 35, 25, 35]
	c. [35, 5, 25, 15] (*)
	d. [30, 35, 25, 10, 5, 15]
	e. []
*/