package collections03.al;

import java.util.ArrayList;

public class CollectAL040_api {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<>();
		
		al.add(25); al.add(10); al.add(35); al.add(20); // Line 1
		al.add(5); al.add(30); al.add(15);				// Line 2
		
		System.out.println(al.get(7));  // Line 3
		al.add(7,  40);					// Line 4
		System.out.println(al.get(7));	// Line 5
		al.add(9, 45); 					// Line 6
		al.set(9,  45); 				// Line 7
	}
}

/*
Which of the above lines will throw IndexOutOfBound Exception?
	a. Lines 3, 6, 7
	b. All lines 1 to 7 
	c. Only line 3.
	d. Lines 3 and 4
	e. Lines 6, 7
*/

// a