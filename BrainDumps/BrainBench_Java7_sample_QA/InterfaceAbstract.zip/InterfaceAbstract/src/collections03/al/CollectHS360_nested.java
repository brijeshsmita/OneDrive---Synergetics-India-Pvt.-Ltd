package collections03.al;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.TreeSet;

public class CollectHS360_nested {

	public static void main(String[] args) {
		// Line 1
		
		LinkedList<String> ll1 = new LinkedList<>();
		ll1.add("aaa"); ll1.add("ccc"); ll1.add("eee");
		outerSet.add(ll1);
		
		LinkedList<String> ll2 = new LinkedList<>();
		ll2.add("ppp"); ll2.add("ttt"); ll2.add("rrr");
		outerSet.add(ll2);
		
		for(LinkedList<String> set : outerSet){
			for(String str : set){
				System.out.print(str + ", ");
			}
			System.out.println();
		}
	}
}

/*
	What kind of statement is correct at line 1?
	a. HashSet<String> outerSet = new HashSet<>();
	b. HashSet<LinkedList<String>> outerSet = new HashSet<>(); (*)
	c. LinkedList<HashSet<String>> outerSet = new LinkedList<>();
	d. TreeSet<LinkedList<String>> outerSet = new TreeSet<>();
*/