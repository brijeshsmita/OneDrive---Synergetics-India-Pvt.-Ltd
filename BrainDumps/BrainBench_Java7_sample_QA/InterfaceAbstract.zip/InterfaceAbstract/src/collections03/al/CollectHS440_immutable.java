package collections03.al;

import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class CollectHS440_immutable {
	public static void main(String[] args) {
		HashSet<List<Integer>> oSet = new HashSet<>();

		final LinkedList<Integer> iList1 = new LinkedList<>();
		iList1.add(15); iList1.add(20); iList1.add(25);  // Line 1
		final List<Integer> iListu1 = Collections.unmodifiableList(iList1);  // Line 2
		
		final LinkedList<Integer> iList2 = new LinkedList<>();
		iList2.add(35); iList2.add(8); iList2.add(12);
		final List<Integer> iListu2 = Collections.unmodifiableList(iList2);
		
		oSet.add(iListu1);
		oSet.add(iListu2);
		
		Set<List<Integer>> oSetU = Collections.unmodifiableSet(oSet);
		iList1.add(19);		// Stmt 1
		
		System.out.println(oSetU);
	}
}

/*
	What is the result of execution?
		a. ClassCastException at Line 2
		b. UnsupportedOperation at Stmt 1
		c. Compile time error at Line 1 as reference is of final type.
		d. [[15, 20, 25, 19], [35, 8, 12]] (*)
		e. [[15, 20, 25], [35, 8, 12]]
*/
