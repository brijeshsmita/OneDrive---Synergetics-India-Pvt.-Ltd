package collections03.al;

import java.util.ArrayList;
import java.util.List;

public class CollectAL030_api {

	public static void main(String[] args) {
		ArrayList<Integer> newEntries = new ArrayList<>();
		newEntries.add(2); newEntries.add(4); newEntries.add(null); // Line 1
		newEntries.add(0, 6); newEntries.add(0, null);		
		
		ArrayList<Integer> entries = new ArrayList<>();
		entries.add(5); entries.add(15); entries.add(10); entries.add(null);
		newEntries.addAll(entries);
		newEntries.addAll(2, entries);
		newEntries.removeIf(val->val==null);  // en: 5 15 10 n
						
		
		List<Integer> selected = newEntries.subList(2, 9); // Line 2
		selected.removeIf(val->val>=10);
		System.out.println(selected);
	}
}

/*
The nearest expected output is...
a. An exception 'NullPointer' at Line 1 as ArrayList can not accommodate 'null'.
b. [2, 4, 5] 
c. [6, 5, 15, 10, 2, 4, 5, 15, 10]
d. [null, 6, 5, 15, 10, null, 2, 4, null, 5, 15, 10, null]
e. An exception 'IndexOutOfBound' at Line 2 as index 9 is out of bound.
*/

// b