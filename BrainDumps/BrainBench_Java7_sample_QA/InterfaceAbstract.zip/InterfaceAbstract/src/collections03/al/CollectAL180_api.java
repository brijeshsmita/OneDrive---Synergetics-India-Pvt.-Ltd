package collections03.al;

import java.util.ArrayList;

public class CollectAL180_api {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<>();
		al.add(5); al.add(10); al.add(15);
		while(al.contains(10)){
			al.add(5);  al.add(15);
			if (al.size()%1001==0){
				al.clear();
				al.add(10);
			}
		}
	}
}

/*
The nearest output of this code is....
	a. Exception: IndexOutOfBound 
	b. The finite execution  
	c. The infinite execution (*)
	d. The OutOfMemoryError
*/
