package collections03.al;

import java.util.HashSet;

public class CollectHS300_props {

	public static void main(String[] args) {
		HashSet<Emp> el = new HashSet<Emp>();

		el.add(null);
		el.add(null);
		
		Emp e1 = new Emp(1, "a");
		Emp e2 = new Emp(1, "b");
		
		el.add(e1);
		el.add(e2);
		
		System.out.println(el);
	}
}

class Emp {
	int empId;
	String eName;
	
	public Emp(int empId, String eName){
		this.empId = empId;
		this.eName = eName;
	}

	@Override
	public String toString() {
		return "Emp [empId=" + empId + "]";
	}
}

/*
	What is the expected result?
	a. Throws Exception as 'null' is not allowed in HashSet
	b. Throws Exception as duplicate employee not allowed
	c. Executes successfully with output: [null, Emp [empId=1]]
	d. Executes successfully with output: [null, Emp [empId=1], Emp [empId=1]] (*)
*/