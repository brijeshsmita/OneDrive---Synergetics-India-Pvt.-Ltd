package collections03.al;

import java.util.ArrayList;
import java.util.List;

public class CollectAL020_api {

	public static void main(String[] args) {
		ArrayList<Integer> newEntries = new ArrayList<>();
		newEntries.add(2); newEntries.add(4);
		newEntries.add(0, 6);				// Line 1 6 2 4
		
		ArrayList<Integer> entries = new ArrayList<>();
		entries.add(5); entries.add(15); entries.add(10);
		newEntries.addAll(entries);
		newEntries.addAll(2, entries);
		System.out.println(newEntries); // 6 2 5 15 10 4 5 15 10 
		
		List<Integer> selected = newEntries.subList(2, 5);
		selected.removeIf(val->val>=10);
		System.out.println(selected);
	}
}

/*
The nearest expected output is...
a. An exception 'IndexOutOfBound' at Line 1.
b. [6, 2, 5, 15, 10, 4, 5, 15, 10]
c. [5, 15, 10]
d. [5]
e. [5, 4]
*/

// d