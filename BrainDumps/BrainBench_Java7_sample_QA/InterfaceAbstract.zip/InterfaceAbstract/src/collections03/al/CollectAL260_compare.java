package collections03.al;

import java.util.ArrayList;

public class CollectAL260_compare {

	public static void main(String[] args) {
		ArrayList<Integer> al2 = new ArrayList<>();
		ArrayList<Integer> al3 = new ArrayList<>();
		
		al2.add(25); al3.add(10); al2.add(35); 
		al3.add(5); al3.add(30); al2.add(15);
		
		al2.sort((val1, val2)->(val1.compareTo(val2)));
		al3.sort((val1, val2)->(val1.compareTo(val2)));
		
		al3.addAll(al2);
		al3.addAll(0, al2);
		
		System.out.println(al3);
	}
}

/* What is the expected output?
	a. Compile time error as sort() is not available on array list.
	b. Run time error as Comparator is not provided
	c. [15, 25, 35, 5, 10, 30, 15, 25, 35]
	d. [5, 10, 15, 15, 25, 25, 30, 35, 35]

*/