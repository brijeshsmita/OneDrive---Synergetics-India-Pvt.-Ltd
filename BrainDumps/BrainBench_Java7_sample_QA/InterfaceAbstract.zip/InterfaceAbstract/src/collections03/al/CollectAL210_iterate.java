package collections03.al;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class CollectAL210_iterate {

	public static void main(String[] args) {
		ArrayList<Integer> al2 = new ArrayList<>();
		ArrayList<Integer> al3 = new ArrayList<>();
		
		al2.add(25); al3.add(10); al2.add(35); 
		al3.add(5); al3.add(30); al2.add(15);
		
		al3.addAll(0, al2);
	
		Iterator<Integer> it = al3.iterator();
		al3.add(50);
		
		while(it.hasNext()){
			System.out.print(it.next()+", ");
		}
		
		ListIterator<Integer> lit = al3.listIterator();
		while(lit.hasNext()){
			System.out.print(lit.next()+", ");
		}
	}
}

/*
	What is the expected output of these statements?
	
	a. 25, 35, 15, 10, 5, 30, 50
	b. IllegalStateException
	c. ConcurrentModificationException (*)
	d. NullPointerException
*/