package collections03.al;

import java.util.ArrayList;

public class CollectAL150_api {

	public static void main(String[] args) {
		ArrayList<Integer> al2 = new ArrayList<>();
		ArrayList<Integer> al3 = new ArrayList<>();
		
		al2.add(25); al3.add(10); al2.add(35); 
		al3.add(5); al3.add(30); al2.add(15);
		
		for(Integer i : al2){
			al3.add(0, i);
		}
	
		for(Integer i : al3){
			al2.add(0, i);
		}
		
		int idx1 = al2.indexOf(35); 
		int idx2 = al2.lastIndexOf(25); 
		int idx3 = al2.indexOf(15);
		
		al2.remove(idx1);
		al2.remove(idx2);
		al2.remove((idx1+idx2)/idx3);
		al2.remove(al2.size()/idx2);
		System.out.println(al2);
	}
}

/*
The nearest output of this code is....
	a. Exception: IndexOutOfBound 
	b. [30, 10, 25, 15, 25, 15]  
	c. [30, 5, 25, 15, 25, 15] 
	d. None of these (*)
*/

