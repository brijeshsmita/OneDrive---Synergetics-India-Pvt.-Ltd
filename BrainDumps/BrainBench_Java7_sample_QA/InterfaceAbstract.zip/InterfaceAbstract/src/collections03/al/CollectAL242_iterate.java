/*
	Which out of following statement is true?
	a. The iterator() internally creates a snapshot of original collection 
		and thus traverses snapshot.
	b. The iterator() refers the original collection and flags a field to prevent
		structural changes.
	c. The iterator works in separate thread than original collection so a structural 
		change to original collection leads to ConcurrentModificationException.
	d. The iterator() wrapps the original collection and forbid a reference to
	 	original collection so it throws exception.
*/












// b
